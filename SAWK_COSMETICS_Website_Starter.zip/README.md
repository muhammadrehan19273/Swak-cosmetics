# SAWK COSMETICS — Website Starter

This is a polished, responsive single-page storefront starter built with HTML, CSS, and vanilla JavaScript. It is suitable for a first GitHub Pages preview and is intentionally easy to replace/edit.

## Run locally
Open `index.html` in a browser, or use VS Code's Live Server extension.

## Deploy as a preview on GitHub Pages
1. Create/open your GitHub repository.
2. Upload `index.html` to the repository root (replace the existing `index.html` only if you want to replace the current page).
3. Commit the change.
4. In repository Settings → Pages, select the deployment source/branch and root folder if not already configured.
5. Wait for GitHub Pages to publish, then test the provided URL on mobile and desktop.

## Important: not production-ready yet
This is a front-end demo, not a full live commerce backend. Product names, images, prices, stock and product copy are sample content and must be replaced with verified SAWK data. Cart/wishlist are saved in the visitor's browser only. Contact and newsletter forms validate locally but do not send data. Checkout does not create an order, collect payment, or connect to an order-management system. Online payments and admin management are not implemented.

Before taking real orders, add a secure backend/database, server-side inventory and order processing, real support endpoints, owner-approved policies, and a verified payment provider. Never put secret keys in front-end JavaScript.

## Easy edits
- Announcement text: search for `Discover your everyday beauty essentials` in `index.html`.
- Sample products: edit the `products` array in the `<script>` section.
- Colors and typography: edit the CSS variables under `:root`.
- Contact and policy copy: edit the Contact and Store Policies sections.
